import scrapy
import datetime

class EconomicIndicators(scrapy.Spider):
    """ Spider para obtener los datos solicitados en el ejercicioes. """
    name = 'datos'
    start_urls = [
        'https://superargo.supersalud.gov.co/formularioWeb/pqrd.php'
    ]

    custom_settings = {
        'FEED_URI': 'datos_clientes.csv',
        'FEED_FORMAT': 'csv',
        'ROBOTSTXT_OBEY': True,
        'FEED_EXPORT_ENCODING': 'utf-8'
    }

    def parse(self, response):
        primernombre =   response.xpath(("//input[@id='nombre_afectado_1']")[0].value).getall()
        segundonombre=   response.xpath(("//input[@id='nombre_afectado_2']")[0].value).getall()
        primerapellido=  response.xpath(("//input[@id='apellidos_afectado_1']")[0].value).getall()
        segundoapellido= response.xpath(("//input[@id='apellidos_afectado_2']")[0].value).getall()
        fechanacimiento= response.xpath(("//input[@id='fecha_nacimiento']")[0].value).getall()
        edad= response.xpath(("//input[@id='edad']")[0].value).getall()
        for prinom, segnom, priape, segape, fenac, eda in zip(primernombre, segundonombre, primerapellido, segundoapellido, fechanacimiento, edad):
            info = {
                'primernombre': prinom,
                'segundonombre' : segnom,  
                'primerapellido' : priape,
                'segundoapellido' : segape,
                'fechanacimiento' : fechanacimiento,
                'edad' : eda,
            }

            yield info



           
      
    

